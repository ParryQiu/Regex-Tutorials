﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Common.Helper;

namespace Regex.Demo.CatchBaidu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCatch_Click(object sender, EventArgs e)
        {
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"<div\s+class=""(result|result-op)\s+c-container\s+.*?<a.*?>(?<title>.*?)</a>", RegexOptions.Singleline | RegexOptions.Compiled);
            var stringUrlAddress = textBoxAddress.Text.Trim();
            var stringPageContent = Common.Helper.NetworkHelper.GetHtmlFromGet(stringUrlAddress, Encoding.UTF8);
            var matches = regex.Matches(stringPageContent);
            listBoxResult.Items.Clear();
            foreach (Match match in matches)
            {
                listBoxResult.Items.Add(match.Groups["title"].ToString().Replace("<em>", string.Empty).Replace("</em>", string.Empty));
            }
            MessageBox.Show("抓取完毕！");
        }
    }
}
